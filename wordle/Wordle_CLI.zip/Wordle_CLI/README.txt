Welcome to the Command Line Interface for Wordle Game.

The game works the same as the NYT Wordle (with the exception of one bug in checking the guess, but it's very minor). To get started, run the python file "wordle_game_encoded.py".

Have fun!